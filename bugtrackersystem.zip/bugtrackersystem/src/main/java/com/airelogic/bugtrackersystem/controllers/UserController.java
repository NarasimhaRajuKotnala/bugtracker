package com.airelogic.bugtrackersystem.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.airelogic.bugtrackersystem.models.User;
import com.airelogic.bugtrackersystem.service.UserService;

@RestController
//@RequestMapping(value = "/api/v1")
public class UserController {
	
	@Autowired
	private UserService userService;
	
	@RequestMapping("/create")
	public String create(@RequestParam String firstName, @RequestParam String lastName, @RequestParam String userName, @RequestParam String password) {
		User user = userService.create(firstName, lastName, userName, password);
		return user.toString();
	}
	
	@RequestMapping("/get")
	public User getUser(@RequestParam String firstName) {
		return userService.getByFirstName(firstName);
	}

	@RequestMapping("/getAll")
	public List<User> getAll(){
		return userService.getAll();
	}
	
	@RequestMapping("/update")
	public String update(@RequestParam String firstName,@RequestParam String lastName, String userName, String password) {
		User user = userService.update(firstName, lastName, userName, password);
		return user.toString();
	}
	
	@RequestMapping("/delete")
	public String delete(@RequestParam String firstName){
		userService.delete(firstName);
		return "Deleted " + firstName;
	}
	
	@RequestMapping("/deleteAll")
	public String deleteAll() {
		userService.deleteAll();
		return "Deleted All Records";
	}




}
