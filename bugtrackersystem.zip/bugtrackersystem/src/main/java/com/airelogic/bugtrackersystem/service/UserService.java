package com.airelogic.bugtrackersystem.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.airelogic.bugtrackersystem.models.User;
import com.airelogic.bugtrackersystem.repositories.UserRepository;

@Service
public class UserService {
	
	@Autowired
	private UserRepository userRepository;
	
	//Create operation
	public User create(String firstName,String lastName,String userName,String password) {
		return userRepository.save(new User(firstName,lastName,userName,password));
	}
	
	//Retrieve operation
	public List<User> getAll(){
		return userRepository.findAll();
	}
	
	public User getByFirstName(String firstName) {
		return userRepository.findByFirstName(firstName);
	}
	
	//Update operation
	public User update(String firstName, String lastName, String userName, String password) {
		User user = userRepository.findByFirstName(firstName);
		user.setLastName(lastName);
		user.setUserName(userName);
		user.setPassword(password);
		return userRepository.save(user);
	}
	
	//Delete operation
	public void deleteAll() {
		userRepository.deleteAll();
	}
	
	//Delete a specific user
	public void delete(String firstName) {
		User user = userRepository.findByFirstName(firstName);
		userRepository.delete(user);
	}
	

}
